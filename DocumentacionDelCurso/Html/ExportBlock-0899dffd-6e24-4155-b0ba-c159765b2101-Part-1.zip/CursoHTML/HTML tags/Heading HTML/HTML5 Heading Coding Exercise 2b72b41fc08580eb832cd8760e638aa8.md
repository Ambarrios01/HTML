# HTML5 Heading Coding Exercise

Write a html code to define second biggest heading that contains "Hello, World!".

Students should be able to create a HTML headings with the appropriate document structure.

```html
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>substitute(Filename('', 'Page Title'), '^.', '\\u&', '')</title>
meta
</head>
<body>
<h2>Hello, World!</h2>
</body>
```

![image.png](HTML5%20Heading%20Coding%20Exercise/image.png)