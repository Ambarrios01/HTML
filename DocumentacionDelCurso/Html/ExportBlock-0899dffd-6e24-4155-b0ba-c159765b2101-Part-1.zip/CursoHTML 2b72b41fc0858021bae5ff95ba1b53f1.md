# CursoHTML

[Historia HTML](CursoHTML/Historia%20HTML%202b72b41fc085808dbf63d9b3b99eeb9d.md)

[Simple HTML Document](CursoHTML/Simple%20HTML%20Document%202b72b41fc08580aca88ace84a8e64e1f.md)

[HTML Page Structure](CursoHTML/HTML%20Page%20Structure%202b72b41fc0858084aa77e8898ed9f7fa.md)

[HTML tags ](CursoHTML/HTML%20tags%202b72b41fc08580bda4eccfbd78d3a59d.md)

[Favicon HTML page](CursoHTML/Favicon%20HTML%20page%202b72b41fc08580dfa45cd56900fdc142.md)